#!/bin/bash

# Show inside CASINO itself that the 50% acceptance target is not the efficiency optimum.
#
#     examples/step_profile/casino_ne_scan.sh [SYSTEM]
#
# One VMC run per time step, all with vmc_method 1 and opt_dtvmc 0 so that the step is exactly
# the one given here. The grid is read from the PyCasino sweep of the same system
# (examples/step_profile/acceptance_1e6/SYSTEM.m1.dat): its time steps, each paired with the
# decorrelation period that minimizes the cost of an independent sample there. The first row is
# what a user gets today, opt_dtvmc 1 and the default period of 3, and it doubles as a check that
# the two codes mean the same thing by dtvmc — CASINO's optimized value should come out at the
# 50% row of the grid.
#
# The figure of merit is the efficiency CASINO prints itself, 1 / (err^2 * CPU time), the inverse
# of the time a run would take to reach a fixed error bar. Nothing is derived here, and the
# acceptance ratio it prints beside it is what the 50% rule is trying to set.

set -e

system=${1:-Ne-gto}
nstep=1000000
# err^2 * CPU time compares runs only if they all use the same number of processes, and CASINO
# splits vmc_nstep between them, so keep nstep a multiple of it
nproc=${NPROC:-4}

case $system in
    Ne-gto)
        src=examples/gwfn/Ne/HF/cc-pVQZ/CBCS/Slater
        out=examples/step_profile/casino_ne
        ;;
    CH4-gto)
        src=examples/gwfn/CH4/HF/cc-pVQZ/CBCS/Slater
        out=examples/step_profile/casino_ch4
        ;;
    *)
        echo "no CASINO scan defined for $system" >&2
        exit 1
        ;;
esac

profile=examples/step_profile/acceptance_1e6/$system.m1.dat
grid=$(
    echo "auto 3"
    LC_ALL=C awk '!/^#/ && $2 >= 0.40 && $2 <= 0.90 {printf "%.5f %d\n", $1, $10}' "$profile"
)

mkdir -p $out
while read -r dtvmc period; do
    dir=$out/$dtvmc.$period
    if [ -f "$dir/out" ]; then
        echo "$dir done"
        continue
    fi
    mkdir -p "$dir"
    cp $src/gwfn.data "$dir/"
    if [ "$dtvmc" = auto ]; then
        opt=1
        dtvmc=0.02
    else
        opt=0
    fi
    grep -v -E '^(vmc_method|vmc_nstep|vmc_nblock|vmc_nconfig_write|vmc_decorr_period|dtvmc|opt_dtvmc) ' $src/input > "$dir/input"
    cat >> "$dir/input" <<EOF

vmc_method        : 1
vmc_nstep         : $nstep
vmc_nblock        : 1
vmc_nconfig_write : 0
vmc_decorr_period : $period
dtvmc             : $dtvmc
opt_dtvmc         : $opt
EOF
    (cd "$dir" && runqmc -p "$nproc" > runqmc.log 2>&1)
    echo "$dir done"
done <<< "$grid"

printf '%9s %7s %9s %9s %12s %8s %11s %7s\n' dtvmc period acc corr_time err cpu efficiency 'vs 1st'
while read -r dtvmc period; do
    dir=$out/$dtvmc.$period
    LC_ALL=C awk -v d="$dtvmc" -v p="$period" '
        /Acceptance ratio/ {acc = $NF}
        /Optimized DTVMC/ {d = $NF}
        /Correlation time  *\(steps\)/ {tau = $(NF - 2)}
        /Correlation time method/ {err = $3}
        /Total CASINO CPU time/ {cpu = ($NF == "s") ? $(NF - 1) : $NF}
        /Efficiency  *\(au/ {eff = $NF}
        END {printf "%9s %7s %9.2f %9.2f %12.6f %8.1f %11.1f\n", d, p, acc, tau, err, cpu, eff}
    ' "$dir/out"
done <<< "$grid" | LC_ALL=C awk 'NR == 1 {base = $7} {printf "%s %6.2fx\n", $0, $7 / base}'
